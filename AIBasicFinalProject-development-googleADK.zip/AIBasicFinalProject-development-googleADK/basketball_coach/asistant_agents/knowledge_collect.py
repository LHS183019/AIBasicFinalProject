from google.adk.agents import Agent
from google.adk.tools import google_search  # Import the tool
import datetime
from zoneinfo import ZoneInfo
from google.adk.agents import Agent
from google.adk.planners import BuiltInPlanner
from google.genai import types as genai_types
from google.adk.tools import agent_tool
from google.adk.code_executors import BuiltInCodeExecutor
import prompt as my_prompt

search_agent = Agent(
   name="basic_search_agent",
   model="gemini-2.0-flash", 
   description=my_prompt.knowledge_collect_agent_description,
   instruction=my_prompt.knowledge_collect_agent_instruction,
   # output_schema=my_prompt.KnowledgeCollectOutput,
   # output_key="get_knowledge",
   tools=[google_search]
)